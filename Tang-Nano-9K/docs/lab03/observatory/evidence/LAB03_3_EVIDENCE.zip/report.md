# LAB-03.3 campaign report

- Created (UTC): 2026-10-20T21:47:03+00:00
- Board: Sipeed Tang Nano 9K / GW1NR-9C
- Git commit: `c977184943cc093c58e4ea857b6556aefbef08b2`
- Bitstream SHA256 (declared, not independently read back from FPGA): `62596847427f0258cb729a8b3c042ab7e0f39a8725990ba39a831b98c6554f13`
- Runs: 12; verified PASS: 12
- Overall capture/MMIO: **PASS**

| Command | Captures | FETCH counts | Event counts | Constant FETCH count? |
|---|---:|---|---|---|
| 0 | 6 | 17, 18, 19, 20 | 18, 19, 20, 21 | NO |
| 4 | 6 | 24, 25, 27, 28 | 25, 26, 28, 29 | NO |

## Scope of this report

PASS certifies captured UART transport, declared probe decoding, archive hashes, snapshot status flags and final LED_WRITE values for the requested commands.
It does **not** certify an instruction-by-instruction match, retired-instruction counts, cycle-level equivalence, absence of unseen events, or LED optical state.
Different FETCH counts are *reported*, not automatically treated as a defect: the capture window and event semantics must first be established.

Raw data in `raw/`; each run's console output in `console/`. Use the matching Git commit and bitstream hash when comparing with RTL.
